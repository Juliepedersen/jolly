# Mobile Web App

Kopier filerne i denne mappe til dine projekter. Det giver en nem start, hvor strukturen med HTML og CSS er på plads fra begyndelsen.

## Mobile First Metoden

1. Begynd med at udvikle koden til mobile enheder.
2. Fortsæt udviklingen med tablets og lignende (fx ipad).

## Mobile First Template

Vi fremstiller en template, der tilpasser sig bredden i flere devices.

**Files**

* index.html = "forside"
* mob-menu.html = menu
* css/reset.css = Meyer reset
* css/style.css = CSS

Photo: by the author.  
Smiley modified with inspiration from a public domain resource.
